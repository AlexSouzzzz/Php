<?php
   function verificar($num1){
        if ($num1 %2 == 0){
           echo "Este número é par: ", $num1;
       }
       else {
           echo "</br> Este número é impar: ", $num1; 
       }
   }
   $num1 = 5;

   verificar ($num1);

?>