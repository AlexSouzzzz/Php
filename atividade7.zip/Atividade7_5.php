<?php
function subtracao($num1, $num2, $num3) {
       $subtracao = $num1 - $num2 - $num3;
       echo "A subtração dos 3 números é igual a: ", $subtracao;
   }

   $num1 = 30;
   $num2 = 20;
   $num3 = 6;

   subtracao($num1, $num2, $num3)
   ?>