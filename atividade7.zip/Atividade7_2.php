<?php
   function soma($num1, $num2, $num3) {
       $soma = $num1 + $num2 + $num3;
       echo "A soma dos 3 números resulta em: ", $soma;
   }

   $num1 = 10;
   $num2 = 20;
   $num3 = 30;

   soma($num1, $num2, $num3)
?>