<?php
  function divisao($num1, $num2) {
    $divisao = $num1 / $num2;
    echo "A divisão dos 2 números resulta em ", $divisao;
}

$num1 = 10;
$num2 = 5;


divisao($num1, $num2)

?>