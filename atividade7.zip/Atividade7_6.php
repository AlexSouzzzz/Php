<?php
$num1 = 4;

echo "o fatorial de ", $num1 ,"!  resulta em: ";

function fatorar($num1)
{
    $fatorial = 1;
    $i = $num1;
    while ($i > 1) {
        $fatorial *= $i;
        $i--;
        echo $fatorial, ";  ";
    }
}


fatorar($num1);




?>