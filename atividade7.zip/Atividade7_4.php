<?php
function multiplicacao($num1, $num2, $num3) {
       $multiplicacao = $num1 * $num2 * $num3;
       echo "A multiplicação dos 3 números é igual a: ", $multiplicacao;
   }

   $num1 = 1;
   $num2 = 4;
   $num3 = 6;

   multiplicacao($num1, $num2, $num3)

?>