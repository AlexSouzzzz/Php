<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        require_once 'Agencia.php';
        $agencia1 = new Agencia();
        $agencia1->setNumero(1);

        $agencia2 = new Agencia();
        $agencia2->setNumero(2);

        $agencia3 = new Agencia();
        $agencia3->setNumero(3);
        require_once 'Conta.php';
        $conta1 = new Conta();
        $conta2 = new Conta();
        $conta3 = new Conta();

        $conta1->setLimite(4000.00);
        $conta1->setNumero(123);
        $conta1->setSaldo(150, 00);
        $conta1->setAgencia($agencia2);

        $conta2->setLimite(7000.00);
        $conta2->setNumero(456);
        $conta2->setSaldo(300, 00);
        $conta2->setAgencia($agencia1);

        $conta3->setLimite(12000.00);
        $conta3->setNumero(789);
        $conta3->setSaldo(900, 00);
        $conta3->setAgencia($agencia3);

        print_r($conta1->mostrarTudo());
        print_r($conta2->mostrarTudo());
        print_r($conta3->mostrarTudo());
        ?>
    </body>
</html>
