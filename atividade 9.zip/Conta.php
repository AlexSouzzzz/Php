<?php

class Conta {

    private int $numero;
    private int $saldo;
    private int $limite;
    private Agencia $agencia;

    public function Conta(int $numero, int $saldo, int $limite, Agencia $agencia) {
        $this->numero = $numero;
        $this->saldo = $saldo;
        $this->limite = $limite;
        $this->agencia = $agencia;
    }

    public function getNumero(): int {
        return $this->numero;
    }

    public function getSaldo(): int {
        return $this->saldo;
    }

    public function getLimite(): int {
        return $this->limite;
    }

    public function setNumero(int $numero): void {
        $this->numero = $numero;
    }

    public function setSaldo(int $saldo): void {
        $this->saldo = $saldo;
    }

    public function setLimite(int $limite): void {
        $this->limite = $limite;
    }

    public function setAgencia(Agencia $agencia): void {
        $this->agencia = $agencia;
    }

    public function mostrarTudo() {
        echo '<br>  A conta de numero ' . strval($this->getNumero()) . ' possui R$' . strval($this->getSaldo()) . ' de saldo  com um limite de R$'
        . strval($this->getLimite() . " e esta registrada na agência " . strval($this->agencia->getNumero()) . '<br>');
    }

}
